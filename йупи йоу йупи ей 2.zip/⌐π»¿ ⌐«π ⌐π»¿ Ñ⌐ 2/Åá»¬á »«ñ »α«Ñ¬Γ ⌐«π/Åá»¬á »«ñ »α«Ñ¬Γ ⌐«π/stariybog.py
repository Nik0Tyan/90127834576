from selectors import SelectSelector
from tkinter import *
import customtkinter as ctk
from PIL import Image, ImageTk
import bcrypt
import base64
import sqlite3
import CTkMessagebox
from pyexpat.errors import messages

connection = sqlite3.connect('iou.db')
cursor = connection.cursor()
root = ctk.CTk()
localpoints=0
currentuser = ""
man=None
# сброс пароля
def password_update():
    login = avtor_entry.get()
    word = word_check.get()
    logincheck1 = cursor.execute("SELECT * FROM users WHERE login = (?)", (login,)).fetchone()
    connection.commit()
    if logincheck1 !=[] and word==logincheck1[4]:
        CTkMessagebox.CTkMessagebox(title="Успех", message="Совпадает", icon="check",topmost=True)
        reset.withdraw()
        reset2.deiconify()
    else:
        CTkMessagebox.CTkMessagebox(title="Ошибка", message="Проверочное слово или логин не совпадает!",
                                icon="cancel", font=("Neuch", 14), topmost=True, )









#Всё что по баллам
def updatepoints():
    global localpoints; global currentuser
    findpoints = cursor.execute("SELECT points FROM users WHERE login = (?)",(currentuser,)).fetchone()
    localpoints = findpoints[0]
    print(f"Количество баллов = {localpoints}")

def point_up():
    global localpoints;
    global admin
    if admin == 1:
        localpoints = localpoints + 1
        point_label.configure(text=f"Ваше количество баллов: {localpoints}")
        cursor.execute("UPDATE users SET points = ? WHERE login = ?", (localpoints, currentuser))
        connection.commit()


def point_down():
    global localpoints;
    global admin
    if admin == 1:
        localpoints = localpoints - 1
        point_label.configure(text=f"Ваше количество баллов: {localpoints}")
        cursor.execute("UPDATE users SET points = ? WHERE login = ?", (localpoints, currentuser))
        connection.commit()
#Регистрация sql
def reg_newuser():
    password = password_entry1.get()
    password_replace = password_entry2.get()
    login = login_entry1.get()
    word = word_entry.get()
    logincheck = cursor.execute("SELECT * FROM users WHERE login = (?)",(login,)).fetchall()
    # Cпросить у дениса как сделать проверку на то что бы почта не совпадала
    if logincheck!=[]:
        CTkMessagebox.CTkMessagebox(title="Ошибка",message="Такой пользователь уже зарегистрирован",icon="cancel",font=("Neucha",16),topmost=True)
    elif password!=password_replace:
        CTkMessagebox.CTkMessagebox(title="Ошибка", message="Пароли не совпадают", icon="cancel",font=("Neucha", 16), topmost=True)
    elif len(login) <1 or len(password) <1:
        CTkMessagebox.CTkMessagebox(title="Ошибка", message="Заполните поля", icon="cancel", font=("Neucha", 16),topmost=True)

    else:
        salt = bcrypt.gensalt()
        password_hash = bcrypt.hashpw(password.encode(), salt)
        clearlogin = login.replace(" ","")
        cursor.execute("INSERT INTO users (login, password, points, word) VALUES (?,?,?,?)",(clearlogin,password_hash,0,word_entry.get()))
        connection.commit()
        CTkMessagebox.CTkMessagebox(title="Уведомление", message="Пользователь был успешно зарегистрирован.",
                                    icon="check", font=("Neuch", 14), topmost=True,)

        swap_auth()

def reg_update():
        password = password_update12.get()
        password_replace = password_update2.get()
        login = login_entry1.get()
        word = word_check.get()
        salt = bcrypt.gensalt()
        password_hash = bcrypt.hashpw(password.encode(), salt)
        cursor.execute("UPDATE users SET password = ? WHERE word = ?", (password_hash, word))
        connection.commit()
        CTkMessagebox.CTkMessagebox(title="Успешно", message="Пароль был сменён.",
                                   icon="check", font=("Neuch", 14), topmost=True, )

        reset2.withdraw()
        root.deiconify()



#Авторизация sql
def avtoriz_user():
    global currentuser; global admin
    password = password_entry.get()
    clearlogin = login_entry.get().replace(" ", "")
    check_user = cursor.execute("SELECT * FROM users WHERE login = (?)",(clearlogin,)).fetchall()
    if check_user==[]:
        CTkMessagebox.CTkMessagebox(title="Ошибка",message="Такого пользователя не существует",icon="cancel",topmost=True)
        return
    if bcrypt.checkpw(password.encode(), check_user[0][2]):
            print('Эщкерямбус')
            check_admin = cursor.execute("SELECT admin FROM users WHERE login = (?)",(clearlogin,)).fetchone()
            if check_admin[0] == 1:
                admin=1
                point_up.pack(pady=10)
                point_down.pack(pady=10)
            home.deiconify()
            root.withdraw()
            currentuser = clearlogin
            updatepoints()
            point_label.configure(text=f"Ваше количество баллов: {localpoints}")


    else:
        CTkMessagebox.CTkMessagebox(title="Ошибка",message="Пароли не совпадают",icon="cancel",topmost=True)

#Свап окошек
def swap_reg():
    reg.deiconify()
    root.withdraw()
def swap_auth():
    root.deiconify()
    reg.withdraw()
def home_list():
    home.deiconify()
    root.withdraw()
def swap_reset():
    root.withdraw()
    reset.deiconify()


root._set_appearance_mode("dark")
root.geometry("400x500")
root.resizable(False,False)
root.title('Окно авторизации')
root.iconbitmap('osel4.ico')
ctk.FontManager.load_font("Neucha-Regular.ttf")
login_label = ctk.CTkLabel(root,text="Логин",font=('Neucha',16),fg_color="transparent");login_label.pack(pady=10)#тут это квадрат почините пж :3
login_entry = ctk.CTkEntry(root,placeholder_text='Введите логин');login_entry.pack(pady=10)
password_label = ctk.CTkLabel(root,text="Пароль",font=('Neucha',16),fg_color="transparent");password_label.pack(pady=10)
password_entry = ctk.CTkEntry(root,placeholder_text='Введите пароль',show="*");password_entry.pack(pady=10)
avtor_button = ctk.CTkButton(root,font=('Neucha',16),text= "Войти",command=avtoriz_user);avtor_button.pack(pady=10)
swap_button = ctk.CTkButton(root,font=('Neucha',16),text= "Регистрация",fg_color="transparent", hover_color="#242424",command=swap_reg);swap_button.place(x=130,y=455)
swap_button1 = ctk.CTkButton(root,font=('Neucha',16),text= "Сброс пароля",fg_color="transparent", hover_color="#242424",command=swap_reset);swap_button1.place(x=130,y=420)
#Регистрация

reg = ctk.CTk()
reg._set_appearance_mode("green-dark")
reg.geometry("400x500")
reg.resizable(False,False)
reg.title('Окно регистрации')
reg.iconbitmap('osel4.ico')
ctk.FontManager.load_font("Neucha-Regular.ttf")
login_label1 = ctk.CTkLabel(reg,text="Логин",font=('Neucha',16),fg_color="transparent");login_label1.pack(pady=10)#тут это квадрат почините пж :3
login_entry1 = ctk.CTkEntry(reg,placeholder_text='Придумайте логин');login_entry1.pack(pady=10)
password_label1 = ctk.CTkLabel(reg,text="Пароль",font=('Neucha',16),fg_color="transparent");password_label1.pack(pady=10)
password_entry1 = ctk.CTkEntry(reg,placeholder_text='Придумайте пароль',show="*");password_entry1.pack(pady=10)
password_label2 = ctk.CTkLabel(reg,text="Подтвердите пароль",font=('Neucha',16),fg_color="transparent");password_label2.pack(pady=10)
password_entry2 = ctk.CTkEntry(reg,placeholder_text='Повторите пароль',show="*");password_entry2.pack(pady=10)
word_label = ctk.CTkLabel(reg,text="Проверочное слово",font=('Neucha',16),fg_color="transparent");word_label.pack(pady=10)
word_entry = ctk.CTkEntry(reg,placeholder_text='Проверочное слово');word_entry.pack(pady=10)
register_button = ctk.CTkButton(reg,font=('Neucha',16),text= "Зарегистрировать",command=reg_newuser);register_button.pack(pady=10)
swap_button1 = ctk.CTkButton(reg,font=('Neucha',16),text= "Авторизация",fg_color="transparent", hover_color="#242424",command=swap_auth);swap_button1.place(x=130,y=455)


home = ctk.CTk()
home._set_appearance_mode("dark")
home.iconbitmap('osel4.ico')
home.geometry("400x500")
home.resizable(False,False)
home.title('Окно авторизации')
ctk.FontManager.load_font("Neucha-Regular.ttf")
home_label = ctk.CTkLabel(home,text="Ваша учётная запись",font=('Neucha',16),fg_color="transparent");home_label.pack()
point_label = ctk.CTkLabel(home,text=f"Ваше количество баллов: {localpoints}",font=('Neucha',16),fg_color="transparent");point_label.pack()
point_up = ctk.CTkButton(home,font=('Neucha',16),text="Поднять конфеток",command=point_up)
point_down = ctk.CTkButton(home,font=('Neucha',16),text="Опустить конфеток",command=point_down)

reset = ctk.CTk()
reset._set_appearance_mode("dark")
reset.iconbitmap('osel4.ico')
reset.geometry("400x500")
reset.resizable(False,False)
reset.title('Окно сброса пароля')
ctk.FontManager.load_font("Neucha-Regular.ttf")
avtor_label = ctk.CTkLabel(reset,text="Введите логин учётной записи",font=('Neucha',16));avtor_label.pack()
avtor_entry = ctk.CTkEntry(reset,placeholder_text="Логин сюда",font=('Neucha',16),fg_color="transparent");avtor_entry.pack()
word_check = ctk.CTkEntry(reset,placeholder_text="Введите проверочное слово",font=('Neucha',16),fg_color="transparent");word_check.pack()
password_reset = ctk.CTkButton(reset,font=('Neucha',16),text="Сброс",command=password_update);password_reset.pack(pady=10)

reset2 = ctk.CTk()
reset2._set_appearance_mode("dark")
reset2.iconbitmap('osel4.ico')
reset2.geometry("400x500")
reset2.resizable(False,False)
reset2.title('Окно смены пароля')
password_label1 = ctk.CTkLabel(reset2,text="Пароль",font=('Neucha',16),fg_color="transparent");password_label1.pack(pady=10)
password_update12 = ctk.CTkEntry(reset2,placeholder_text='Придумайте пароль',);password_update12.pack(pady=10)
password_label2 = ctk.CTkLabel(reset2,text="Подтвердите пароль",font=('Neucha',16),fg_color="transparent");password_label2.pack(pady=10)
password_update2 = ctk.CTkEntry(reset2,placeholder_text='Повторите пароль',);password_update2.pack(pady=10)
password_update1 =ctk.CTkButton(reset2,font=('Neucha',16),text="Cброс пароля",command=reg_update);password_update1.pack(pady=10)
root.mainloop()


